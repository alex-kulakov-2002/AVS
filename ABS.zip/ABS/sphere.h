#ifndef __sphere__
#define __sphere__

#include "random.h"
#include <stdio.h>
#include <stdbool.h>
#include "processingExceptions.h"


struct sphere{
    int radius;
};

void InputSphere(struct sphere *sphere, FILE* inputFile);

void RandomSphere(struct sphere *sphere);

void OutputSphere(struct sphere *sphere, FILE* outputFile);

double VolumeSphere (struct sphere *sphere);

#endif
