#include "sphere.h"
#include <math.h>

#define PI 3.141593

void RandomSphere(struct sphere *sphere) {
    sphere->radius = Random();
}

void InputSphere(struct sphere *sphere, FILE* inputFile){
    bool radius = InputInt(inputFile, &sphere->radius);
    if (!radius){
        printf("Radius is incorrect, because of that it will be one");
    }
}

double VolumeSphere(struct sphere *sphere) {
    return 4.0 / 3 * PI * sphere->radius * sphere->radius * sphere->radius;
}

void OutputSphere(struct sphere *sphere, FILE* outputFile){
    fprintf(outputFile, "Sphere:\n");
    fprintf(outputFile, "radius = %d\n", sphere->radius);
    fprintf(outputFile, "volume = %f\n", VolumeSphere(sphere));
}
