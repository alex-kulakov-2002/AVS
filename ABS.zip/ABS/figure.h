#ifndef __figure__
#define __figure__
#include "tetrahedron.h"
#include "parallelepiped.h"
#include "sphere.h"
#include <stdio.h>
#include <stdbool.h>
#include "processingExceptions.h"
#include "random.h"

struct figure{
    int density;

    enum witch {TETRAHEDRON, PARALLELEPIPED, SPHERE};

    enum witch w;

    union {
        struct tetrahedron t;
        struct parallelepiped p;
        struct sphere s;
    };
};

struct figure *InputFigure (FILE* inputFile);

struct figure *RandomFigure();

void OutputFigure(struct figure *figure, FILE* outputFile);

double VolumeFigure(struct figure *figure);

#endif
