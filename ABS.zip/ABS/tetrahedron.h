#ifndef __tetrahedron__
#define __tetrahedron__

#include "random.h"
#include <stdio.h>
#include <stdbool.h>
#include "processingExceptions.h"


struct tetrahedron{
    int lengthOfLine;
};

void InputTetrahedron(struct tetrahedron *tetrahedron, FILE* inputFile);

void RandomTetrahedron(struct tetrahedron *tetrahedron);

void OutputTetrahedron(struct tetrahedron *tetrahedron, FILE* outputFile);

double VolumeTetrahedron (struct tetrahedron *tetrahedron);

#endif
