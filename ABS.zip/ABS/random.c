#include "random.h"

int Random(){
    return rand() % 100 +1;
}

int RandomOneToThree(){
    return rand() % 3 +1;
}
