#ifndef __processingExceptions__
#define __processingExceptions__

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

bool InputInt(FILE* inputFile, int *inputInt);

#endif
