#include <stdio.h>
#include <string.h>
#include "container.h"
#include "time.h"

typedef struct container container;

int main(int argc, char* argv[]) {
    clock_t time_start = clock();
    if (argc != 5){
        return 1;
    }

    container con;
    Init(&con);
    if (!strcmp(argv[1], "-f")){
        FILE *inputFile = fopen(argv[2], "a+");
        Input(&con, inputFile);
    }
    else if (!strcmp (argv[1], "-n")){
        long size = strtol(argv[2], &argv[2], 0);
        if ((size < 1) || (size > 10000)){
            printf("Error");
            return 1;
        }
        srand(time(NULL));
        RandomContainer(&con, (int)size);
    }
    else{
        printf("Error");
        return 1;
    }

    FILE *outputFile1;
    if (!(outputFile1 = fopen(argv[3], "w+"))){
        printf("Error");
        return 1;
    }

    fprintf(outputFile1, "Filled container:\n");
    OutPut(&con, outputFile1);
    fclose(outputFile1);

    FILE *outputFile2;
    if (!(outputFile2 = fopen(argv[4], "w+"))){
        printf("Error");
        return 1;
    }
    fprintf(outputFile2, "Changed container: \n");
    ShapeByVolume(&con);
    OutPut(&con, outputFile2);
    fclose(outputFile2);
    Clear(&con);
    printf("Seconds: %f", ((double)(clock() - time_start))/ CLOCKS_PER_SEC);
    return 0;
}