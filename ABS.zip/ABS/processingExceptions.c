#include "processingExceptions.h"

bool InputInt (FILE* inputFile, int *inputInt){
    int number = fscanf(inputFile, "%d", inputInt);
    if (number == 0 || number == EOF){
        *inputInt=1;
        return false;
    }
    return true;
}

