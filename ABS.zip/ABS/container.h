#ifndef __contanier__
#define __container__

#include "figure.h"
#include <stdio.h>
#include "stdlib.h"

typedef struct figure figure;

struct container {
    int len;
    enum {max_len = 10000};
    figure *container[max_len];
};

void Init(struct container *container);

void Clear(struct  container *container);

void RandomContainer(struct container *container, int size);

void Input(struct container *container, FILE* inputFile);

double AverageVolume(struct container *container);

void OutPut(struct container *container, FILE* outputFile);

void ShapeByVolume(struct container *container);
#endif
