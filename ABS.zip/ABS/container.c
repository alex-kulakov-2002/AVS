#include "container.h"

void Init(struct container *container) {
    container->len = 0;
}

void Clear(struct container *container) {
    for (int i = 0; i < (*container).len; i++) {
        free(container->container[i]);
    }
    container->len = 0;
}

void Input(struct container *container, FILE *inputFile) {
    while ((container->container[container->len] = InputFigure(inputFile)) != NULL) {
        container->len++;
    }
    fclose(inputFile);
}

void RandomContainer(struct container *container, int size) {
    while (container->len < size) {
        if (((container->container[container->len] = RandomFigure()) != NULL)) {
            container->len++;
        }
    }
}

double AverageVolume(struct container *container) {
    double sum = 0;
    for (int i = 0; i < container->len; i++) {
        sum += VolumeFigure(container->container[i]);
    }
    return sum / container->len;
}

void OutPut(struct container *container, FILE *outputFile) {
    fprintf(outputFile, "Container :\n");
    for (int i = 0; i < container->len; i++) {
        OutputFigure(container->container[i], outputFile);
    }
}

void ShapeByVolume(struct container *container) {
    double avarage = AverageVolume(container);
    int i = 0;
    int j = 0;

    while (j < container->len) {
        if (VolumeFigure(container->container[j]) < avarage) {
            if (i == j) {
                i++;
                j++;
            } else {
                j++;
            }
        } else {
            if (i >= container->len) {
                break;
            }
            if (VolumeFigure(container->container[i]) <= avarage) {
                struct figure *f = container->container[i];
                container->container[i] = container->container[j];
                container->container[j] = f;
                i++;
                j++;
            } else {
                i++;
            }
        }
    }

}