#include "figure.h"

typedef struct figure figure;

void Density(struct figure *figure, int density){
    figure->density=density;
}

figure* InputFigure(FILE* inputFile){
    figure *fig;
    fig = (figure*)malloc(sizeof (figure));
    int typeoffigure;
    bool figureType = InputInt(inputFile, &typeoffigure);
    int density;
    bool boolDensity = InputInt(inputFile, &density);
    if (!figureType || !boolDensity){
        return NULL;
    }
    fig->density=density;
    switch (typeoffigure) {
        case 1:
            fig->w= SPHERE;
            InputSphere(&(fig->s), inputFile);
            return fig;
        case 2:
            fig->w = PARALLELEPIPED;
            InputParallelepiped(&(fig->p), inputFile);
            return  fig;
        case 3:
            fig->w= TETRAHEDRON;
            InputTetrahedron(&(fig->t), inputFile);
            return fig;
        default:
            return NULL;
    }
}

struct figure *RandomFigure(){
    figure *fig;
    int typeoffigure = RandomOneToThree();
    int density= Random();
    fig = (figure*)malloc(sizeof (figure));
    fig->density=density;
    switch (typeoffigure) {
        case 1:
            fig->w= SPHERE;
            RandomSphere(&(fig->s));
            return fig;
        case 2:
            fig->w = PARALLELEPIPED;
            RandomParallelepiped(&(fig->p));
            return  fig;
        case 3:
            fig->w= TETRAHEDRON;
            RandomTetrahedron(&(fig->t));
            return fig;
        default:
            return NULL;
    }
}

void OutputFigure(struct figure *figure, FILE* outputFile){
    switch (figure->w) {
        case SPHERE:
            OutputSphere(&(figure->s), outputFile);
            fprintf(outputFile,"Density = %d\n", figure->density);
            break;
        case TETRAHEDRON:
            OutputTetrahedron(&(figure->t), outputFile);
            fprintf(outputFile,"Density = %d\n", figure->density);
            break;
        case PARALLELEPIPED:
            OutputParallelepiped(&(figure->p), outputFile);
            fprintf(outputFile,"Density = %d\n", figure->density);
            break;
        default:
            fprintf(outputFile,"Bad figure");
    }
}

double VolumeFigure(struct figure *figure){
    switch (figure->w) {
        case SPHERE:
            return VolumeSphere(&(figure->s));
        case PARALLELEPIPED:
            return VolumeParallelepiped(&(figure->p));
        case TETRAHEDRON:
            return VolumeTetrahedron(&(figure->t));
        default:
            return 0;
    }
}
