#ifndef __random__
#define __random__

#include <stdlib.h>

int Random();

int RandomOneToThree();

#endif
